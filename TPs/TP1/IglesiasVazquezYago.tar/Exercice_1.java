public class Exercice_1 {
    public static void main(String[] args) {
        /*
         * Exercice 1
         * 
         * Le type de sorti de la méthode main est void
         * 
         * Exercice 2
         * 
         * Pour le tester il suffit de faire dans le terminal
         * $java Exercice_1 arg1 arg2
         * et cela affiche 2
         * 
         * Exercice 3
         * 
         * String.length()
         * 
         * Exercice 4
         * 
         * Il appartient à la classe Math
         * 
         */

         System.out.println(args.length);
    }
}
