public class Tour extends Piece {

    public Tour(boolean couleur) {
        super(couleur, "tour");
    }
    
}
