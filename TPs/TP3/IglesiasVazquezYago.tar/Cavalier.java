public class Cavalier extends Piece {

    public Cavalier(boolean couleur) {
        super(couleur, "Cavalier");
    }
    
}
