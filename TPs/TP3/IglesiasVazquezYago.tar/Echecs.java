public class Echecs {


    public static void main(String[] args) {
        Plateau plateau = new Plateau(8, 8);

        for (int i = 0; i < 8; i++){
            plateau.remplirCase(1, i, new Pion(false));
            plateau.remplirCase(6, i, new Pion(true));
        }

        plateau.remplirCase(0, 0, new Tour(false));
        plateau.remplirCase(0, 7, new Tour(false));
        plateau.remplirCase(7, 0, new Tour(true));
        plateau.remplirCase(7, 7, new Tour(true));

        plateau.remplirCase(0, 1, new Cavalier(false));
        plateau.remplirCase(0, 6, new Cavalier(false));
        plateau.remplirCase(7, 1, new Cavalier(true));
        plateau.remplirCase(7, 6, new Cavalier(true));

        plateau.remplirCase(0, 2, new Fou(false));
        plateau.remplirCase(0, 5, new Fou(false));
        plateau.remplirCase(7, 2, new Fou(true));
        plateau.remplirCase(7, 5, new Fou(true));

        plateau.remplirCase(0, 3, new Dame(false));
        plateau.remplirCase(7, 3, new Dame(true));
        
        plateau.remplirCase(0, 4, new Roi(false));
        plateau.remplirCase(7, 4, new Roi(true));

        plateau.afficher();

    }
    
}
