public class Dame extends Piece {

    public Dame(boolean couleur) {
        super(couleur, "dame");
    }
    
}
