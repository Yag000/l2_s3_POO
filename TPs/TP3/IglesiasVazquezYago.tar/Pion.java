public class Pion extends Piece{

    public Pion(boolean couleur) {
        super(couleur, "pion");
    }

    @Override
    public boolean estValide(Deplacement d, Plateau p){
        if (!super.estValide(d, p)) return false;

        if(d.getY1() == d.getY0() + 1 ) return true;

        if(d.getY1() == d.getY0() + 2 && this.couleur ?   d.getY0() == p.getLongeur() - 2 :  d.getY0() == 1) return true;

        return false

    }
    
}
