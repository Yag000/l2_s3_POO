public class Fou extends Piece {

    public Fou(boolean couleur) {
        super(couleur, "fou");
    }
    
}
