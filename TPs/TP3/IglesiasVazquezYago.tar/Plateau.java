public class Plateau {
    private int longeur, largeur;
    private Case[][] plateau;


    public Plateau(int longeur, int largeur) {
        this.longeur = longeur;
        this.largeur = largeur;
        this.plateau = new Case[longeur][largeur];

        for (int i = 0; i < longeur; i++){
            for (int j = 0; j < largeur; j++){
                plateau[i][j] = new Case((i + j) % 2 == 1);
            }
        }
    }

    /**
     * Cette fonction renvoie vrai si les coordonnées données sont dans les limites du plateau.
     * 
     * @param i le numéro de ligne
     * @param j le numéro de colonne
     * @return La valeur booléenne de l'instruction.
     */
    public boolean horsLimite(int i, int j){
        return i < longeur && i >= 0 && j < largeur && j>= 0;
    }

    /**
     * Cette fonction renvoie vrai si les coordonnées du premier point du mouvement sont hors du
     * plateau
     * 
     * @param deplacement le mouvement à vérifier
     * @return Une valeur booléenne.
     */
    public boolean horsLimite(Deplacement deplacement){
        return horsLimite(deplacement.getX1(),deplacement.getY1());
    }


    public Case getCase(int i, int j){
        if (!this.horsLimite(i, j)) return null;
        return plateau[i][j];
    }

    public void videCase(int x, int y){
        if (this.horsLimite(x, y)) plateau[x][y].enleverPiece();
    }

    /**
     * Il remplit une caisse avec un piece
     * 
     * @param x la coordonnée x du cas
     * @param y la coordonnée y de la pièce
     * @param p la pièce à placer sur le plateau
     */
    public void remplirCase(int x, int y, Piece p){
        if (this.horsLimite(x, y)) plateau[x][y].remplirPiece(p);
    }


    public void afficher(){
        for (int i = 0; i < longeur; i++){
            for (int j = 0; j < largeur; j++){
                System.out.print(this.plateau[i][j] + " ");
            }
            System.out.println();
        }
    }

    public boolean intermVides(Deplacement d){
        switch(d.typeDeplacement()){
            case 'h': 
                for (int i = d.getX0(); i <= d.getX1(); i++) if (!plateau[i][d.getY0()].estVide()) return false;
                return true;
            case 'v': 
                for (int j = d.getY0(); j <= d.getY1(); j++) if (!plateau[d.getX0()][j].estVide()) return false;
                return true;
            default: return true;
        }
    }

    public int getLongeur() {
        return longeur;
    }

    public int getLargeur() {
        return largeur;
    }
    
}
